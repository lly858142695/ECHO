# ECHO Next Crash Report

Generated: 2026-05-20T00:28:44.979Z
Report file: crash-report.md

## Summary

- Type: no_crash_recorded
- Message: No normal crash has been recorded in this session.
- Reason: n/a
- Exit code: n/a
- Crash timestamp: n/a

## Session

```json
{
  "sessionId": "[redacted]",
  "appVersion": "26.5.19",
  "electronVersion": "37.10.3",
  "chromeVersion": "138.0.7204.251",
  "nodeVersion": "22.21.1",
  "platform": "win32",
  "arch": "x64",
  "startedAt": "2026-05-20T00:27:30.263Z",
  "status": "running"
}
```

## Last Abnormal Session

```json
null
```

## Crash Details

```json
{
  "message": "No crash.json exists for the current session."
}
```

## Stack

```text
n/a
```

## Safe Runtime Snapshots

### Playback

```json
{
  "state": "stopped",
  "currentTrackId": null,
  "positionSeconds": 0,
  "durationSeconds": 0,
  "currentFilePath": null
}
```

### Audio

```json
{
  "host": "ready",
  "state": "stopped",
  "outputDeviceId": null,
  "outputDeviceName": null,
  "outputDeviceType": null,
  "outputBackend": null,
  "activeOutputBackendImpl": null,
  "outputMode": "system",
  "sharedBackend": "auto",
  "useJuceOutputRequested": false,
  "useJuceDecodeRequested": false,
  "activeDecodeBackendImpl": "ffmpeg",
  "dsdOutputModeRequested": "pcm",
  "activeDsdOutputMode": null,
  "dsdNativeSampleRate": null,
  "dsdTransportSampleRate": null,
  "latencyProfile": {
    "basename": "balanced",
    "pathHash": "c0905088ba5b8067"
  },
  "volume": 0.17,
  "playbackRate": 1,
  "playbackSpeedMode": "nightcore",
  "replayGainEnabled": false,
  "replayGainMode": "track",
  "replayGainAppliedDb": 0,
  "replayGainPreventedClipping": false,
  "automix": {
    "enabled": false,
    "mode": "off",
    "active": false,
    "transitionSeconds": null,
    "transitionStartedAtSeconds": null,
    "nextTrackId": null,
    "transitionMode": null,
    "fallbackReason": null,
    "beatAligned": false,
    "skipIntroSilence": false,
    "engine": null,
    "tempoRatio": null,
    "nextStartSeconds": null,
    "overlapSeconds": null,
    "advanceAtSeconds": null,
    "plannedTrackCount": 0,
    "nextTransitionIndex": 0
  },
  "currentFilePath": null,
  "currentTrackId": null,
  "durationSeconds": 0,
  "positionSeconds": 0,
  "channels": null,
  "codec": null,
  "bitDepth": null,
  "bitrate": null,
  "fileSampleRate": null,
  "decoderOutputSampleRate": null,
  "requestedOutputSampleRate": null,
  "actualDeviceSampleRate": null,
  "sharedDeviceSampleRate": null,
  "resampling": false,
  "ffmpegPath": {
    "basename": "ffmpeg.exe",
    "pathHash": "ef67dcbeab491f75"
  },
  "ffmpegSource": "bundled",
  "ffmpegVersion": "8.1.1-full_build-www.gyan.dev",
  "ffmpegHealthy": true,
  "soxrAvailable": true,
  "resamplerEngine": "default",
  "resamplerFallbackActive": false,
  "bitPerfectCandidate": false,
  "sampleRateMismatch": false,
  "eqEnabled": false,
  "channelBalanceEnabled": false,
  "dspActive": false,
  "preampDb": 0,
  "eqPresetName": "Flat",
  "clippingRisk": false,
  "audioLevels": {
    "inputPeakDb": null,
    "inputRmsDb": null,
    "estimatedOutputPeakDb": null,
    "estimatedOutputRmsDb": null,
    "headroomDb": null,
    "clipCount": 0,
    "lastClipAt": null,
    "meterSource": "pre_native_estimated_post_dsp"
  },
  "bitPerfectDisabledReason": null,
  "sharedStabilityTier": null,
  "nativeDeviceBufferFrames": null,
  "nativeRequestedBufferFrames": null,
  "nativeActualBufferFrames": null,
  "nativeOutputLatencyMs": null,
  "nativePositionStalenessMs": null,
  "nativeFifoCapacityFrames": null,
  "nativeStartupPrebufferFrames": null,
  "nativeBufferedFrames": null,
  "nativeBufferedMs": null,
  "nativeUnderrunCallbacks": 0,
  "nativeUnderrunFrames": 0,
  "lastSharedStabilityRecoveryAt": null,
  "warnings": [],
  "error": null,
  "asioOutputChannelStart": null
}
```

### App Settings

```json
{
  "appMemoryVersion": 2,
  "locale": "zh-CN",
  "appearanceTheme": "light",
  "appearanceThemePreset": "nyanCat",
  "appearanceThemePresetOverrides": {},
  "appearancePreferences": {
    "mainFontFamily": "Outfit",
    "mainFontFilePath": null,
    "chineseFontFamily": "Microsoft YaHei",
    "chineseFontFilePath": null,
    "baseFontSize": 14,
    "lineHeight": 1.35,
    "textDepth": 62
  },
  "songsSort": "default",
  "rememberedAudioOutput": {
    "enabled": false,
    "outputMode": "shared",
    "sharedBackend": "auto",
    "latencyProfile": {
      "basename": "balanced",
      "pathHash": "c0905088ba5b8067"
    }
  },
  "hiddenAudioDeviceKeys": [],
  "audioUseJuceOutput": true,
  "audioUseJuceDecode": false,
  "audioDsdOutputMode": "pcm",
  "audioAsioNativeDsdExperimentalEnabled": false,
  "audioAsioUnavailableFallbackEnabled": false,
  "audioSoxrFallbackEnabled": true,
  "audioReleaseExclusiveOnPauseExperimentalEnabled": false,
  "albumMergeStrategy": "standard",
  "chineseCrossScriptSearchEnabled": true,
  "artistWallAlbumArtwork": false,
  "artistWallAlbumFallbackForMissingAvatars": false,
  "autoFetchArtistImages": false,
  "artistImageFetchPaused": false,
  "liveLibraryUpdatesEnabled": false,
  "liveLibraryAutoHideDeletedEnabled": false,
  "autoUpdateEnabled": true,
  "autoAccountCheckOnStartup": true,
  "suppressAccountExpiryNotices": false,
  "spotifyAutoLaunchOfficialPlayer": true,
  "connectAutoStartReceiversEnabled": false,
  "playlistBackupsEnabled": true,
  "coverCacheDir": null,
  "hideToTrayOnClose": false,
  "rememberWindowSizeEnabled": true,
  "rememberedWindowSize": {
    "width": 1407,
    "height": 882
  },
  "appCustomWallpaperPath": null,
  "appWallpaperMediaType": "image",
  "appWallpaperScalePercent": 100,
  "appWallpaperBlurPx": 0,
  "appWallpaperBrightnessPercent": 100,
  "appWallpaperUiOpacityPercent": 100,
  "appWallpaperVisualProtectionEnabled": true,
  "appWallpaperUnifiedOpacityEnabled": false,
  "appVideoWallpaperPauseMode": "smart",
  "networkMetadataEnabled": false,
  "networkMetadataProviders": [
    "netease-cloud-music",
    "qq-music"
  ],
  "audioAnalysisEnabled": true,
  "lyricsNetworkEnabled": true,
  "lyricsPreferredProvider": "lrclib",
  "lyricsEnabledProviders": [
    "local",
    "lrclib",
    "netease",
    "qqmusic"
  ],
  "lyricsProviderOrder": [
    "local",
    "lrclib",
    "netease",
    "qqmusic"
  ],
  "lyricsProviderTimeoutMs": 4500,
  "lyricsTotalMatchTimeoutMs": 6000,
  "lyricsCoverAutoAcceptScore": 0.97,
  "lyricsDeepSearchEnabled": true,
  "lyricsAutoSearch": true,
  "lyricsAutoAcceptScore": 0.5,
  "lyricsDefaultOffsetMs": 0,
  "lyricsGlobalSyncOffsetMs": 0,
  "lyricsOffsetControlsEnabled": false,
  "lyricsEnabled": true,
  "lyricsHeaderHidden": false,
  "lyricsMvAutoShowTrackInfoDisabled": true,
  "lyricsCandidatePanelAutoOpenEnabled": true,
  "lyricsEmptyStateHidden": true,
  "lyricsPlayerBarDrawerEnabled": false,
  "lyricsPlayerBarDrawerOpacityPercent": 78,
  "lyricsPlayerBarDrawerColorMode": "default",
  "lyricsPlayerBarDrawerColor": "#232120",
  "lyricsRomanizationEnabled": true,
  "lyricsTranslationEnabled": true,
  "lyricsWordHighlightEnabled": true,
  "lyricsFontSizePx": 40,
  "lyricsSecondaryFontSizePx": 22,
  "lyricsFontFamily": "Microsoft YaHei",
  "lyricsFontFilePath": null,
  "lyricsLineSpacingPercent": 110,
  "lyricsLineMaxChars": 0,
  "lyricsContextOpacityPercent": 49,
  "lyricsColor": "#314054",
  "lyricsSmartReadableColorsEnabled": false,
  "lyricsHighResolutionNetworkCoverEnabled": false,
  "lyricsBackgroundMode": "theme",
  "lyricsCustomWallpaperPath": null,
  "lyricsCoverOpacityPercent": 100,
  "lyricsCoverBlurPx": 10,
  "lyricsCoverBrightnessPercent": 100,
  "lyricsBackgroundScalePercent": 100,
  "mvEnabled": true,
  "mvEnabledProviders": [
    "bilibili",
    "youtube"
  ],
  "mvProviderOrder": [
    "bilibili",
    "youtube"
  ],
  "mvAutoSearch": true,
  "mvAutoPreload": true,
  "mvAutoApplyThreshold": 0.7,
  "mvPreferHighestViewCount": false,
  "mvImmersiveBackground": true,
  "mvImmersiveBackgroundScalePercent": 115,
  "mvImmersiveBackgroundOffsetXPercent": 50,
  "mvImmersiveBackgroundOffsetYPercent": 50,
  "mvImmersiveBackgroundBlurPx": 0,
  "mvImmersiveBackgroundBrightnessPercent": 100,
  "mvImmersiveBackgroundOverlayOpacityPercent": 0,
  "mvLyricsReadabilityEnhanced": false,
  "mvRestartAudioOnLoad": true,
  "mvSyncMode": "balanced",
  "mvReplayAudioOnChange": true,
  "mvMaxQuality": "max",
  "mvAllow60fps": true,
  "channelBalance": {
    "enabled": false,
    "balance": 0,
    "leftGainDb": 0,
    "rightGainDb": 0,
    "swapLeftRight": false,
    "monoMode": "off",
    "invertLeft": false,
    "invertRight": false,
    "constantPower": true
  },
  "playerVolume": 0.17,
  "replayGainEnabled": false,
  "replayGainMode": "track",
  "replayGainTargetLufs": -18,
  "replayGainPreampDb": 0,
  "replayGainPreventClipping": true,
  "replayGainAnalyzeOnPlay": true,
  "replayGainAnalyzeMissingOnScanOptIn": false,
  "replayGainAnalyzeMissingOnScan": false,
  "backgroundSpacePauseEnabled": false,
  "globalShortcuts": {
    "playPause": {
      "enabled": false,
      "accelerator": null
    },
    "previousTrack": {
      "enabled": false,
      "accelerator": null
    },
    "nextTrack": {
      "enabled": false,
      "accelerator": null
    },
    "stop": {
      "enabled": false,
      "accelerator": null
    },
    "volumeUp": {
      "enabled": false,
      "accelerator": null
    },
    "volumeDown": {
      "enabled": false,
      "accelerator": null
    },
    "seekBackward": {
      "enabled": false,
      "accelerator": null
    },
    "seekForward": {
      "enabled": false,
      "accelerator": null
    },
    "showMainWindow": {
      "enabled": false,
      "accelerator": null
    },
    "bossKey": {
      "enabled": false,
      "accelerator": null
    },
    "speedUp": {
      "enabled": false,
      "accelerator": null
    },
    "speedDown": {
      "enabled": false,
      "accelerator": null
    },
    "openAudioSettings": {
      "enabled": false,
      "accelerator": null
    },
    "openMvSettings": {
      "enabled": false,
      "accelerator": null
    },
    "openLyricsSettings": {
      "enabled": false,
      "accelerator": null
    }
  },
  "playbackSpeed": 1,
  "playbackSpeedMode": "nightcore",
  "scanPerformanceMode": "balanced",
  "duplicateTracksEnabled": true,
  "duplicateTracksMode": "strict",
  "duplicateTracksAutoRebuildAfterScan": false,
  "discordRichPresenceEnabled": false,
  "lastFmEnabled": false,
  "lastFmUsername": null,
  "lastFmSessionKey": "[redacted]",
  "lastFmScrobbleEnabled": true,
  "lastFmNowPlayingEnabled": true,
  "lastFmMinScrobbleSeconds": 30,
  "lastFmAuthToken": "[redacted]",
  "smtcEnabled": true,
  "taskbarPlaybackControlsEnabled": false
}
```

## Recent Logs

### crash.log

```text
n/a
```

### main.log

```text
{"timestamp":"2026-05-20T00:27:30.264Z","scope":"main","level":"info","message":"diagnostics session started","payload":{"sessionId":"[redacted]"}}
{"timestamp":"2026-05-20T00:27:30.453Z","scope":"main","level":"info","message":"[SMTC] Windows SMTC host initialized","payload":{"hostPath":{"basename":"echo-smtc-host.exe","pathHash":"80755d319d962450"}}}
```

### renderer.log

```text
n/a
```

## Privacy

This report is generated locally. Music files, cover binaries, lyric contents, tokens, cookies, and authentication secrets are not included. Local media paths are reduced to basename plus pathHash when captured through diagnostics snapshots.

